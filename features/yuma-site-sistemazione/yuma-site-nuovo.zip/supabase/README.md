# Supabase – YUMA Team

## 1. Esegui lo schema (in QUEST'ordine)

Apri Supabase Dashboard → il tuo progetto → **SQL Editor → New query**, incolla il
contenuto di ciascun file e premi **Run**, uno dopo l'altro:

| # | File | Cosa fa |
|---|---|---|
| 1 | `schema.sql` | tabelle `site_content`, `candidature`, `profiles` + trigger |
| 2 | `members.sql` | tabella `members` (equipaggio con foto) |
| 3 | `registration.sql` | registrazione con approvazione admin + ruoli `socio` / `yuma` |
| 4 | `fix_rls.sql` | corregge la ricorsione infinita delle policy su `profiles` |
| 5 | `99-fix-policies.sql` | **fonte di verità**: `is_admin()` canonico, DELETE candidature, elenco membri per gli approvati, blocco escalation su `profiles`, limiti anti-spam. Va eseguito **per ultimo** |
| 6 | `100-aree-riservate.sql` | helper `is_approved_member()` / `is_yuma()` per le due aree |
| 7 | `101-aree-contenuti.sql` | tabella `area_items` (schede dentro le due aree) + policy: leggono i soci/equipaggio, scrive solo l.admin |

Tutti i file sono idempotenti: si possono rieseguire.

> ⚠️ `schema.sql`, `registration.sql` e `fix_rls.sql` ridefiniscono `is_admin()` con
> semantiche diverse (l'ultimo eseguito vince). Rispetta l'ordine della tabella.

## 2. Crea l'utente admin
1. Authentication → Users → Add user
2. Email: `klaus68@hotmail.it`
3. Password a tua scelta
4. Abilita Auto Confirm User
5. Create user

Il trigger assegna automaticamente `role = admin` a questa email.

## 3. Config client
URL e anon key sono in `app.js` (righe 1-2).

**Non** mettere mai la service_role key nel frontend.

## Le due aree riservate

| Area | Sezione | Chi la vede | Contenuto |
|---|---|---|---|
| **Area Soci** | `#area-soci` | utenti loggati con `status = 'approved'` → ruoli `socio`, `yuma`, `admin` | ruolo personale, prossimi passi, blocco Download (placeholder), elenco membri approvati |
| **Area YUMA** | `#area-yuma` | **solo** `role = 'yuma'` (+ `admin`), sempre con `status = 'approved'` | card Download equipaggio (placeholder), strumenti del team, equipaggio YUMA attivo |

I contenuti elencati dentro le due aree **li pubblica solo l'admin**, dal pannello admin →
tab **Aree**: voci con titolo, descrizione e link (PDF, Drive, Discord...), salvate nella
tabella `downloads` con `area = 'soci'` oppure `area = 'yuma'`.

La distinzione è implementata in `app.js`:

- `loadUserProfile()` imposta `isAdmin` e `isYuma`;
- `updateAuthUI()` mostra/nasconde `.nav-area-soci` e `.nav-area-yuma` e le due sezioni;
- `renderAreaSoci()` / `renderAreaYuma()` generano il contenuto;
- al logout o quando i permessi decadono le due aree vengono **svuotate**, non solo nascoste (`clearArea()`);
- `renderAdminDownloads()` / `addDownload()` / `saveDownload()` / `deleteDownload()` gestiscono i contenuti dal pannello admin.

> 🔒 La UI non è una protezione: le policy RLS di `101-aree-contenuti.sql` fanno sì che i soci
> approvati leggano solo `area='soci'`, l'equipaggio YUMA tutto, e che **solo `is_admin()`
> possa inserire, modificare o eliminare**.

## Tabelle
| Tabella | Uso |
|---------|-----|
| site_content | Testi del sito (hero, equipaggio) |
| candidature | Form Unisciti a noi |
| profiles | Ruolo utente (`admin` / `yuma` / `socio` / `pending`) e stato (`pending` / `approved` / `rejected`) |
| members | Schede equipaggio mostrate in home |
| downloads | Contenuti delle due aree (`area='soci'` / `area='yuma'`), gestiti dal tab "Aree" del pannello admin |

## Test
```bash
npm i --no-save jsdom
node tests/aree-riservate.test.js
```
Verifica la visibilità delle due aree per ospite, socio, yuma, pending e admin.
