# YUMA Team – sito ufficiale

Sito vetrina del team **YUMA** (Virtual Skipper, 25° anniversario), con area riservata
ai soci e area riservata all'equipaggio.
Online: **https://klaus681.github.io/yuma-site/**

## Stack

- HTML/CSS/JS puri, **nessun build step** (deploy diretto da GitHub Pages, branch `main`, root)
- Tailwind via Play CDN + Google Fonts (Orbitron / Rajdhani)
- Backend: **Supabase** (Auth + Postgres + RLS)
- i18n in **IT / EN / ES / FR** (`i18n.js`, switch client-side con `localStorage`)
- Test delle aree riservate con **jsdom**

## Struttura

| File | Ruolo |
|---|---|
| `index.html` | pagina unica: nav, hero, storia, trofei, roster, "Unisciti", Area Soci, YUMA Only, modale admin |
| `app.js` | client Supabase: auth, ruoli/approvazioni, CRUD contenuti/membri/candidature, rendering delle aree |
| `i18n.js` | dizionari IT/EN/ES/FR + switcher lingua |
| `favicon.svg` | icona del sito |
| `supabase/` | migrazioni SQL + `README.md` con l'ordine di esecuzione |
| `tests/aree-riservate.test.js` | test di visibilità delle due aree |

## Le due aree riservate

| Area | Sezione | Chi la vede |
|---|---|---|
| **Area Soci** | `#area-soci` | utenti approvati: `socio`, `yuma`, `admin` |
| **Area YUMA** | `#area-yuma` | **solo** `role = 'yuma'` (+ `admin`), con `status = 'approved'` |

Tutto quello che sta **dentro** le due aree (schede con titolo, testo e link) lo crea e
modifica solo l'admin, dal pannello → tab **Aree**; le schede sono salvate in `area_items`
con `area = 'soci'` oppure `area = 'yuma'`.

> ⚠️ La visibilità è lato client: **non è una protezione**. I contenuti riservati
> (a partire dai file dell'area download) vanno protetti con le policy RLS.

## Setup backend

Segui `supabase/README.md`: 6 file SQL in ordine, con `99-fix-policies.sql` per ultimo
(è la fonte di verità delle policy e di `is_admin()`).

## Sviluppo locale

Serve solo un server statico (le `fetch` verso Supabase richiedono `http://`, non `file://`):

```bash
python3 -m http.server 8080
# poi apri http://localhost:8080
```

## Test

```bash
npm i --no-save jsdom
node tests/aree-riservate.test.js
```

Copre ospite, socio, yuma, pending, admin, logout e traduzioni.

## Deploy

Push su `main` → GitHub Pages ricostruisce da root. Non c'è build: `index.html`,
`app.js`, `i18n.js` e `favicon.svg` vengono serviti così come sono.

## Da fare (idee)

- **Upload file** dirette (oggi le schede contengono link a Drive/Discord/PDF; si può
  aggiungere Supabase Storage con bucket e policy RLS per area)
- `og-image.png` 1200×630 per le anteprime social (esportala dal PSD originale)
- Tailwind precompilato al posto del Play CDN (performance / niente FOUC)
